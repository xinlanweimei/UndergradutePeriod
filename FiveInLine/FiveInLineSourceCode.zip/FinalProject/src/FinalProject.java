// File Name:       FinalProject.java

// Author:          Su Zhihua ������־��
// Student Number:  3012218121
//Class:            Class 2

//Description:     The final project and assignment is to make the Arcade Line 
//                 game (or Five In A Line game). That means if there are at least
//                 five "same" balls in a line, these balls will disappear and the
//                 player will get some scores.

//Future Improvements:  1.To make the balls look like balls instead of just
//                      a circle, we can use Class LinearGradient to finish
//                      it. But I reference some images that can make the
//                      window more beautiful.
//                      2.When a piece has been selected, with FX I reference
//                      an image about the sign instead of the drop shadow.
//                      3.I reference an image about the background and an
//                      image about the game is over.
//                      4.To make each grid has stereo feeling, I use Class
//                      Lighting to accomplish the effect.
//                      5.Once the size is changed, something will be not
//                      adjustable. So I use the method setResizable() to
//                      make the player can`t change the size.

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PathTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Lighting;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;


public class FinalProject extends Application
{
    BorderPane root = new BorderPane();
    AnchorPane anc = new AnchorPane();
    Tiles [][]tiles = new Tiles[9][9];
    Text text = new Text();
    Fill [][]fill = new Fill[9][9];
    int getRow1 = 0;
    int getCol1 = 0;
    int getRow2 = 0;
    int getCol2 = 0;
    //To store the path that the ball move along.
    Path []path = new Path[100];
    int []queue = new int[100];
    static int total = 0;
    int tot = 0;
    PathTransition []pathTransition = new PathTransition[100];
    //Define eight directions to check whether there are at least five 
    //"same" balls in a line.
    static final int[][] DIRECTION = {{1,0},{-1,0},{0,1},{0,-1},
                                    {1,1},{1,-1},{-1,1},{-1,-1}};
    int getPath[][] = new int[9][9];
    //To get the kind of the next three balls.
    int []kin = new int[3];
    //To get the number of lines that are freed according to the requisition. 
    int times = 1;
    //To get total score of the game.
    static int totalScore = 0;

    public static void main(String[] args)
    {
        FinalProject.launch(args);
    }


    public void start(Stage stage)
    {
        stage.setTitle("Five In A Line");
        //Reference an image about the background.
        Image image = new Image(FinalProject.class.getResource("15.gif")
                                .toExternalForm(),450,550,false,false);
        ImageView background = new ImageView(image);
        Scene scene = new Scene(root,450,550);
        Button button = new Button("Restart Game");
        root.getChildren().add(background);
        root.setTop(button);
        BorderPane.setAlignment(button,Pos.CENTER);
        Board board = new Board();
        Bottom bottom = new Bottom();
        button.setOnAction(new RestartListener());
        //To make the player can`t change the size of the window.
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
    //The class Bottom is to achieve the functions that add the scores and the 
    //next three balls and update them. 
    public class Bottom
    {
        HBox hbox1 = new HBox();
        HBox hbox2 = new HBox();
        HBox hbox3 = new HBox();
        HBox hbox4 = new HBox();
        HBox hbox5 = new HBox();
        public Bottom()
        {
            hbox2.setPrefWidth(225);
            hbox3.setPrefWidth(225);
            Text text1 = new Text();
            text1.setText("Score:");
            text1.setFont(new Font(23));
            text.setFont(new Font(23));
            text.setText(" " + totalScore);
            hbox4.getChildren().add(text);
            hbox4.setAlignment(Pos.BOTTOM_CENTER);
            hbox2.getChildren().addAll(text1,hbox4);
            hbox2.setAlignment(Pos.BOTTOM_LEFT);
            Text text2 = new Text();
            text2.setText("Next:");
            text2.setFont(new Font(23));
            Fill fill = new Fill();
            int numb = 0;
            while(numb < 3)
            {
                hbox5.getChildren().add(fill.getFill());
                kin[numb] = fill.number;
                numb++;
            }
            hbox3.getChildren().addAll(text2,hbox5);
            hbox3.setAlignment(Pos.BOTTOM_RIGHT);
            hbox1.getChildren().addAll(hbox2,hbox3);
            root.setBottom(hbox1);
        }
    }
    //The class Fill is to make every tile can add balls, bomb and sign.
    public class Fill
    {
        public int number = 0;
        public ImageView imageview = new ImageView();
        public ImageView imagevie = new ImageView();
        //Show the "wild" ball that can match all of the colors.
        public ImageView getMixture()
        {
            number = 11;
            Image image = new Image(FinalProject.class.getResource(number + ".gif")
                                            .toExternalForm(),45,45,false,false);
            ImageView mixture = new ImageView(image);
            imageview = mixture;
            return mixture;
        }
        //Show 7 different colored balls.
        public ImageView getSingleColor()
        {
            number = (int)(Math.random() * 7) + 1;
            Image image = new Image(FinalProject.class.getResource(number + ".gif")
                                            .toExternalForm(),45,45,false,false);
            ImageView singleColor = new ImageView(image);
            imageview = singleColor;
            return singleColor;
        }
        //Show 3 types of balls that have two colors.
        public ImageView getDoubleColor()
        {
            number = (int)(Math.random() * 3) + 8;
            Image image = new Image(FinalProject.class.getResource(number + ".gif")
                                             .toExternalForm(),45,45,false,false);
            ImageView doubleColor = new ImageView(image);
            imageview = doubleColor;
            return doubleColor;
        }
        //Show the bomb.
        public ImageView getBomb()
        {
            number = 12;
            Image image = new Image(FinalProject.class.getResource(number + ".gif")
                                             .toExternalForm(),45,45,false,false);
            ImageView bomb = new ImageView(image);
            imageview = bomb;
            return bomb;
        }
        //Show the sign when the ball is selected.
        public ImageView getSign()
        {

            Image image = new Image(FinalProject.class.getResource("13.gif")
                                        .toExternalForm(),20,20,false,false);
            ImageView sign = new ImageView(image);
            imagevie = sign;
            return sign;
        }
        //Show the balls according to the probability. 
        public ImageView getFill()
        {
            int num = (int)(Math.random() * 100) + 1;
            if(num <= 77)
                return getSingleColor();
            else if(num <= 92)
                return getDoubleColor();
            else if (num <= 96)
                return getMixture();
            else return getBomb();
        }
        public ImageView getImage(int num)
        {
            number = num;
            Image image = new Image(FinalProject.class.getResource(number + ".gif")
                                            .toExternalForm(),45,45,false,false);
            ImageView imag = new ImageView(image);
            imageview = imag;
            return imag;
        }
        public int getNumber()
        {
            return this.number;
        }
    }
    //The class Board is to initialize the board.
    public  class Board
    {

        public Board()
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    fill[i][j] = new Fill();
                    tiles[i][j] = new Tiles(i,j);
                    //I use the setOnMouseMoved() to get the distance between the
                    //top of the AnchorPane and the bottom of the button. It`s 15.
                    AnchorPane.setTopAnchor(tiles[i][j],(double)((i * 50) + 15));
                    AnchorPane.setLeftAnchor(tiles[i][j],(double)(j * 50));
                    tiles[i][j].setOnMouseClicked(new ClickListener());
                    tiles[i][j].setOnMouseEntered(new EnterListener());
                    tiles[i][j].setOnMouseExited(new ExitedListener());
                    anc.getChildren().add(tiles[i][j]);
                }
            }
            //Put five balls on the board.
            int numb = 0;
            while(numb < 5)
            {
                Tiles til = new Tiles();
                int row = til.getI();
                int column = til.getJ();
                if(tiles[row][column].kind == 0)
                {
                    tiles[row][column].getChildren().add
                                           (fill[row][column]. getSingleColor());
                    tiles[row][column].kind = fill[row][column].getNumber();
                    numb++;
                }
            }
            root.setCenter(anc);
        }
    }
    //The class Tiles is to make a grid. And it can add its children the center 
    //automatically. 
    public class Tiles extends StackPane
    {
        public int i;
        public int j;
        public int kind;
        Rectangle rec = new Rectangle(50,50);
        public Tiles() {};
        public Tiles(int x,int y)
        {
            this.setPrefSize(50, 50);
            i = x;
            j = y;
            rec.setStroke(Color.BLACK);
            rec.setEffect(new Lighting());
            rec.setFill(Color.YELLOWGREEN);
            this.getChildren().add(rec);
        };
        public int getI()
        {
            i = (int)(Math.random() * 9);
            return i;
        }
        public int getJ()
        {
            j = (int)(Math.random() * 9);
            return j;
        }
    } 
    public class ClickListener implements EventHandler<MouseEvent>
    {
        ImageView ima = new ImageView();
        public void handle(MouseEvent mouse)
        {
            if(!isGamOver())
            {
                tiles[getRow1][getCol1].getChildren()
                .remove(fill[getRow1][getCol1].imagevie);
                Tiles tie = (Tiles)(mouse.getSource());
                int row = tie.i;
                int col = tie.j;
                if(tiles[row][col].kind != 0)
                {
                    tot = 1;
                    getRow1 = row;
                    getCol1 = col;
                    getFrom(getRow1,getCol1);
                    tiles[getRow1][getCol1].getChildren().
                    add(fill[getRow1][getCol1].getSign());
                }
                else
                {
                    if(tot == 1)
                    {
                        getRow2 = row;
                        getCol2 = col;
                        if(getRow2 != getRow1 || getCol2 != getCol1)
                        {
                            if(getPath[getRow2][getCol2] > 0)
                            {
                               tiles[getRow1][getCol1].getChildren().
                               remove(fill[getRow1][getCol1].imageview);
                               tiles[getRow1][getCol1].kind = 0;
                               Fill fills = new Fill();
                               ima = fills.getImage(fill[getRow1][getCol1].number);
                               anc.getChildren().add(ima);
                               for(int i = 0; i < total; i++)
                               {
                                    pathTransition[i] = new PathTransition();
                                    pathTransition[i].setDuration
                                    (Duration.millis(100));
                                    pathTransition[i].setPath(path[i]);
                                    pathTransition[i].setNode(ima);
                                }
                               SequentialTransition seqT =
                                    new SequentialTransition ();
                               for(int i = 1; i <= total; i++)
                                {
                                   seqT.getChildren().add(pathTransition[total-i]);
                                }
                               seqT.play();
                               seqT.setOnFinished(new EventHandler<ActionEvent>()
                                {
                                    public void handle(ActionEvent event)
                                    {
                                        anc.getChildren().remove(ima);
                                        ImageView imageV = new ImageView();
                                        imageV = fill[getRow2][getCol2].
                                          getImage(fill[getRow1][getCol1].number);
                                        tiles[getRow2][getCol2].getChildren()
                                                                  .add(imageV);
                                        tiles[getRow2][getCol2].kind =
                                            fill[getRow1][getCol1].number;
                                        int score = clearElements(getRow2,getCol2);
                                        if(score == 0)
                                        {
                                            int num = count();
                                            if(num < 79){
                                            int numb = 0;
                                            while(numb < 3)
                                            {
                                                Tiles til = new Tiles();
                                                int line = til.getI();
                                                int column = til.getJ();
                                                if(tiles[line][column].kind == 0)
                                                {
                                                    ImageView imageView =
                                                        new ImageView();
                                                    imageView =
                                                        fill[line][column]
                                                        .getImage(kin[numb]);
                                                    tiles[line][column].kind =
                                                        kin[numb];
                                                    numb++;
                                                    tiles[line][column].
                                                    getChildren().add(imageView);
                                                    getScore(clearElements
                                                       (line,column),line,column);
                                                }
                                            }
                                            }
                                            else if(num == 79){
                                            	 int numb = 0;
                                                 while(numb < 2)
                                                 {
                                                     Tiles til = new Tiles();
                                                     int line = til.getI();
                                                     int column = til.getJ();
                                                     if(tiles[line][column].kind 
                                                                             == 0)
                                                     {
                                                        ImageView imageView =
                                                             new ImageView();
                                                        imageView =
                                                             fill[line][column]
                                                             .getImage(kin[numb]);
                                                        tiles[line][column].kind
                                                                      = kin[numb];
                                                        numb++;
                                                        tiles[line][column]
                                                                   .getChildren()
                                                                  .add(imageView);
                                                        getScore(clearElements
                                                       (line,column),line,column);
                                                     }
                                                 }
                                            }
                                            else{
                                            	int numb = 0;
                                               while(numb < 1)
                                                {
                                                    Tiles til = new Tiles();
                                                    int line = til.getI();
                                                    int column = til.getJ();
                                                    if(tiles[line][column].kind 
                                                                             == 0)
                                                    {
                                                       ImageView imageView =
                                                            new ImageView();
                                                       imageView =
                                                            fill[line][column]
                                                            .getImage(kin[numb]);
                                                       tiles[line][column].kind =
                                                            kin[numb];
                                                       numb++;
                                                       tiles[line][column]
                                                                   .getChildren()
                                                                  .add(imageView);
                                                       getScore(clearElements
                                                       (line,column),line,column);
                                                    }
                                                }
                                            }
                                            PauseTransition pause = new 
                                             PauseTransition(Duration.seconds(1));
                                            pause.play();
                                            pause.setOnFinished(new EventHandler
                                                                   <ActionEvent>()
                                                    {
                                                        public void handle
                                                               (ActionEvent event)
                                                        {
                                                   if(isGamOver()){ 
                                                    //Reference an image about 
                                                    //game over.
                                                     Image image = 
                                                     new Image(FinalProject
                                                     .class.getResource("14.gif")                    
                                                     .toExternalForm(),450,450,
                                                                     false,false);
                                                     ImageView gameOver = new 
                                                                ImageView(image);
                                                     root.setCenter(gameOver);
                                                     root.setBottom(text);
                                                     text.setText("Your score is " 
                                                                    + totalScore);

                                                  
                                            }
                                                        }
                                                    });
                                          
                                            Bottom bottom = new Bottom();

                                        }
                                        else
                                        {
                                          totalScore += score;
                                          final Text scoreEffect = new Text
                                                                 ("+"+score);
                                          scoreEffect.setX
                                          (tiles[getRow2][getCol2].getLayoutX());
                                          scoreEffect.setY
                                          (tiles[getRow2][getCol2].getLayoutY());
                                          DropShadow shadow = new DropShadow();
                                          shadow.setOffsetX(3.0);
                                          shadow.setOffsetY(3.0);
                                          shadow.setColor(Color.BLACK);
                                          scoreEffect.setEffect(shadow);
                                          scoreEffect.setFont(new Font(15));
                                          scoreEffect.setFill(Color.RED);
                                          FadeTransition fade1 = new
                                          FadeTransition(Duration.millis(300)
                                                           ,scoreEffect);
                                          fade1.setFromValue(0.3);
                                          fade1.setToValue(1);
                                          FadeTransition fade2 = 
                                          new FadeTransition(Duration.millis(800),
                                                               scoreEffect);
                                          fade2.setFromValue(1);
                                          fade2.setToValue(0);
                                          fade2.setDelay(Duration.millis(200));
                                          SequentialTransition scoreFade = 
                                          new SequentialTransition(fade1,fade2);
                                          TranslateTransition scoreMove = new
                                          TranslateTransition(
                                               Duration.millis(1500),scoreEffect);
                                          scoreMove.setDelay(Duration.millis(500));
                                          scoreMove.setFromX(0);
                                          scoreMove.setFromY(0);
                                          scoreMove.setToY(
                                                         -tiles[getRow2][getCol2].
                                                         getLayoutY() - 50);
                                          scoreMove.setToX(
                                                         -tiles[getRow2][getCol2].
                                                         getLayoutX() + 50);
                                          ParallelTransition scoreParallel =
                                                            new ParallelTransition
                                                            (scoreFade,scoreMove);
                                          scoreParallel.play();
                                          scoreParallel.setOnFinished(
                                                new EventHandler<ActionEvent> ()
                                          {
                                                 public void handle
                                                               (ActionEvent event)
                                                {
                                                    anc.getChildren().
                                                    remove(scoreEffect);

                                                }
                                            });
                                            anc.getChildren().add(scoreEffect);
                                            text.setText(" " + totalScore);
                                        }

                                    }


                                });

                                for(int i = 0;  i < getPath.length; i++)
                                {
                                    for(int j = 0; j < getPath[i].length; j++)
                                    {
                                        getPath[i][j] = 0;
                                    }
                                }


                            }
                        }
                        else
                        {
                            tiles[getRow2][getCol2].getChildren()
                            .remove(fill[getRow2][getCol2].getSign());
                            tiles[getRow2][getCol2].getChildren()
                            .add(fill[getRow2][getCol2].getSign());
                            tiles[getRow2][getCol2].kind  =
                                fill[getRow1][getCol1].number;
                        }
                        tot = 0;
                    }
                }
            }
        }

    }
    //To get the path when the mouse enter a certain tile.
    public class EnterListener implements EventHandler<MouseEvent>
    {
        public void handle(MouseEvent mouse)
        {
            Tiles tie = (Tiles)((mouse.getSource()));
            int i = tie.i;
            int j = tie.j;

            for(int m = 0; m < path.length; m++)
            {
                path[m] = new Path();
            }

            if(getPath[i][j] > 0)
            {
                total = 0;

                while (getPath[i][j] > 0)
                {
                    if (getPath[i][j] == 1)
                    {
                        tiles[i][j].rec.setFill(Color.BLANCHEDALMOND);
                        queue[total] = 9 * i + j;
                        LineTo line1 = new LineTo((j + 0.5) * 50,
                                                  (i + 0.5) * 50 + 15);
                        MoveTo move1 = new MoveTo((j + 0.5) * 50,
                                                  (i + 1.5) * 50 + 15);
                        path[total].getElements().add(move1);
                        path[total].getElements().add(line1);
                        path[total].setOpacity(0);
                        anc.getChildren().add(path[total]);
                        total++;
                        i++;
                    }
                    else if (getPath[i][j] == 2)
                    {
                        tiles[i][j].rec.setFill(Color.BLANCHEDALMOND);
                        queue[total] = 9 * i + j;
                        LineTo line1 = new LineTo((j + 0.5) * 50,
                                                 (i + 0.5) * 50 + 15);
                        MoveTo move1 = new MoveTo((j + 1.5) * 50,
                                                 (i + 0.5) * 50 + 15);
                        path[total].getElements().add(move1);
                        path[total].getElements().add(line1);
                        path[total].setOpacity(0);
                        anc.getChildren().add(path[total]);
                        total++;
                        j++;

                    }
                    else if (getPath[i][j] == 3)
                    {
                        tiles[i][j].rec.setFill(Color.BLANCHEDALMOND);
                        queue[total] = 9 * i + j;
                        LineTo line1 = new LineTo((j + 0.5) * 50,
                                                  (i + 0.5) * 50 + 15);
                        MoveTo move1 = new MoveTo((j + 0.5) * 50,
                                                  (i - 0.5) * 50 + 15);
                        path[total].getElements().add(move1);
                        path[total].getElements().add(line1);
                        path[total].setOpacity(0);
                        anc.getChildren().add(path[total]);
                        total++;
                        i--;

                    }
                    else if (getPath[i][j] == 4)
                    {
                        tiles[i][j].rec.setFill(Color.BLANCHEDALMOND);
                        queue[total] = 9 * i + j;
                        LineTo line1 = new LineTo((j + 0.5) * 50,
                                                  (i + 0.5) * 50 + 15);
                        MoveTo move1 = new MoveTo((j - 0.5) * 50,
                                                   (i + 0.5) * 50 + 15);
                        path[total].getElements().add(move1);
                        path[total].getElements().add(line1);
                        path[total].setOpacity(0);
                        anc.getChildren().add(path[total]);
                        total++;
                        j--;
                    }

                }
            }
            else if(getPath[i][j] == 0)
            {

                for(int m = 0; m < total; m++)
                {
                    int row = queue[m] / 9;
                    int column = queue[m] % 9;
                    tiles[row][column].rec.setFill(Color.YELLOWGREEN);
                    anc.getChildren().remove(path[m]);
                }
            }


        }
    }
    //Remove the path when the mouse exited.
    public class ExitedListener implements EventHandler <MouseEvent>
    {
        public void handle(MouseEvent mouse)
        {
            for(int m = 0; m < total; m++)
            {
                int row = queue[m] / 9;
                int column = queue[m] % 9;
                tiles[row][column].rec.setFill(Color.YELLOWGREEN);
                anc.getChildren().remove(path[m]);
            }


        }
    }
    //Initialize the game.
    public  class RestartListener implements EventHandler<ActionEvent>
    {
        public void handle(ActionEvent act)
        {
            totalScore = 0;
            Board board = new Board();
            Bottom bottom = new Bottom();
            for(int i = 0; i < getPath.length; i++)
            {
                for(int j = 0; j < getPath[i].length; j++)
                {
                    getPath[i][j] = 0;
                }
            }
        }
    }
    //Mark every tile by using BFS.  
    void getFrom(int i,int j)
    {
        int[] que = new int[100];
        for (int k = 0; k < 9; k++)
            for (int l = 0; l < 9; l++)
                getPath[k][l] = 0;
        int p = 0,q = 0;
        que[q++] = i * 9 + j;
        getPath[i][j] = -1;
        while (p != q)
        {
            i = que[p] / 9;
            j = que[p] % 9;
            p++;
            if (i > 0 && tiles[i - 1][j].kind == 0 && getPath[i - 1][j] == 0)
            {
                que[q++] = (i - 1) * 9 + j;
                getPath[i - 1][j] = 1;
            }
            if (j > 0 && tiles[i][j - 1].kind == 0 && getPath[i][j - 1] == 0)
            {
                que[q++] = i * 9 + j - 1;
                getPath[i][j - 1] = 2;
            }
            if (i < 8 && tiles[i + 1][j].kind == 0 && getPath[i + 1][j] == 0)
            {
                que[q++] = (i + 1) * 9 + j;
                getPath[i + 1][j] = 3;
            }
            if (j < 8 && tiles[i][j + 1].kind == 0 && getPath[i][j + 1] == 0)
            {
                que[q++] = i * 9 + j + 1;
                getPath[i][j + 1] = 4;
            }
        }

    }
    //To check if two balls are "equal".
    boolean equal (int kind1,int kind2)
    {
        if (kind1 == 0 || kind2 == 0) return false;
        if (kind1 == kind2) return true;
        //Once there is one ball that is a bomb or a "wild" ball, they are equal.
        if (kind1 > 10 || kind2 > 10) return true;
        int temp1,temp2;
        if (kind1 < kind2)
        {
            temp1 = kind1;
            temp2 = kind2;
        }
        else
        {
            temp1 = kind2;
            temp2 = kind1;
        } 
        //There is one ball that has two kinds of colors.
        if (temp2 == 8 && (temp1 == 4 || temp1 == 6)) return true;
        if (temp2 == 9 && (temp1 == 1 || temp1 == 5)) return true;
        if (temp2 == 10 && (temp1 == 2 || temp1 == 7)) return true;
        return false;
    }
    //To check if it is in the AnchorPane.
    boolean inAnc(int x)
    {
        return x >= 0 && x < 9;
    }
    int clearElements(int i,int j)
    {
        int score = 0;
        int[] clearLine = new int[10];
        int[] bomb = new int[10];
        for (int tmp = 0; tmp < 8; tmp++)
        {
            int[] array = new int[2];
            check(i,j,DIRECTION[tmp][0],DIRECTION[tmp][1],array);
            clearLine[tmp] = array[0];
            bomb[tmp] = array[1];
        }

        sort(clearLine);
        sort(bomb);
        for (int tmp = 0; tmp < 8; tmp++)
        {
            clearAllBall(bomb[tmp]);
            if (clearLine[tmp] != 0)
            {
                score += times * clearLine[tmp];
                times++;
            }
        }

        if (score > 0)
        {
            tiles[i][j].getChildren().remove(fill[i][j].imageview);
            tiles[i][j].kind = 0;
        }
        return score;
    }
    void sort(int[]x)
    {
        for (int i = 7; i > 0; i--)
        {
            for (int j = 0; j < i; j++)
            {
                if (x[j] > x[j + 1])
                {
                    x[j] ^= x[j + 1];
                    x[j + 1] ^= x[j];
                    x[j] ^= x[j + 1];
                }
                
            }
        }
    }
    //To clear all balls of the same kind.
    void clearAllBall(int kind)
    {
        if (kind == 0) return;
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if (kind == tiles[i][j].kind)
                {
                    tiles[i][j].getChildren().remove(fill[i][j].imageview);
                    tiles[i][j].kind = 0;
                }
            }
        }
    }
    //If there are at least five balls in a line, clear them and record scores.
    void check(int i,int j,int tmpi,int tmpj,int[] array)
    {
        int kind = tiles[i][j].kind, num = 1,k = 1;
        boolean isBomb = (tiles[i][j].kind == 12);
        while (inAnc(i + k * tmpi) && inAnc(j + k * tmpj) &&
                equal(tiles[i + k * tmpi][j + k * tmpj].kind,kind))
        {
            num++;
            isBomb |= (tiles[i + k * tmpi][j + k * tmpj].kind == 12);
            if (kind > tiles[i + k * tmpi][j + k * tmpj].kind)
                kind = tiles[i + k * tmpi][j + k * tmpj].kind;
            k++;
        }
        if (k > 1)
        {
            k = 1;
            while (inAnc(i - k * tmpi) && inAnc(j - k * tmpj) &&
                    equal(tiles[i - k * tmpi][j - k * tmpj].kind,kind))
            {
                num++;
                isBomb |= (tiles[i - k * tmpi][j - k * tmpj].kind == 12);
                if (kind > tiles[i - k * tmpi][j - k * tmpj].kind)
                    kind = tiles[i - k * tmpi][j - k * tmpj].kind;
                k++;
            }
        }
        if (num >= 5)
        {
            array[0] = (num - 5) * 2 + 3;
            if (isBomb)
            {
                array[1] = kind;
            }
            k = 1;
            while (inAnc(i + k * tmpi) && inAnc(j + k * tmpj) &&
                    equal(tiles[i + k * tmpi][j + k * tmpj].kind,kind))
            {
                tiles[i + k * tmpi][j + k * tmpj].getChildren()
                              .remove(fill[i + k * tmpi][j + k * tmpj].imageview);
                tiles[i + k * tmpi][j + k * tmpj].kind = 0;
                k++;
            }
            if (k > 1)
            {
                k = 1;
                while (inAnc(i - k * tmpi) && inAnc(j - k * tmpj) &&
                        equal(tiles[i - k * tmpi][j - k * tmpj].kind,kind))
                {
                    tiles[i - k * tmpi][j - k * tmpj].getChildren()
                              .remove(fill[i - k * tmpi][j - k * tmpj].imageview);
                    tiles[i - k * tmpi][j - k * tmpj].kind = 0;
                    k++;
                }
            }
        }
    }
    //To check if the game is over.
    boolean isGamOver()
    {
       int num = count();
        if(num == 81)
            return true;
        else
            return false;
    }
    //To get the number of the balls in the board.
    int count(){
    	int num = 0;
    	  for(int i = 0; i < 9; i++)
              for(int j = 0; j < 9; j++)
              {
                  if(tiles[i][j].kind != 0)
                  {
                      num++;
                  }
              }
    	 return num;
    }
    //To update the score.
    void getScore(int score,int row,int column)
    {
        if(score == 0)
        {
            times = 1;
        }
        else
        {
            totalScore += score;
            final Text scoreEffect = new Text("+"+score);
            scoreEffect.setX(tiles[row][column].getLayoutX());
            scoreEffect.setY(tiles[row][column].getLayoutY());
            DropShadow shadow = new DropShadow();
            shadow.setOffsetX(3.0);
            shadow.setOffsetY(3.0);
            shadow.setColor(Color.BLACK);
            scoreEffect.setEffect(shadow);
            scoreEffect.setFont(new Font(15));
            scoreEffect.setFill(Color.RED);
            FadeTransition fade1 = new FadeTransition(Duration.millis(300),
                                                            scoreEffect);
            fade1.setFromValue(0.3);
            fade1.setToValue(1);
            FadeTransition fade2 = new FadeTransition(Duration.millis(800),
                                                            scoreEffect);
            fade2.setFromValue(1);
            fade2.setToValue(0);
            fade2.setDelay(Duration.millis(200));
            SequentialTransition scoreFade = new SequentialTransition(fade1,fade2);
            TranslateTransition scoreMove = new TranslateTransition
                                              (Duration.millis(1500),scoreEffect);
            scoreMove.setDelay(Duration.millis(500));
            scoreMove.setFromX(0);
            scoreMove.setFromY(0);
            scoreMove.setToY(-tiles[row][column].getLayoutY() - 50);
            scoreMove.setToX(-tiles[row][column].getLayoutX() + 50);
            ParallelTransition scoreParallel = new ParallelTransition
            (scoreFade,scoreMove);
            scoreParallel.play();
            scoreParallel.setOnFinished(new EventHandler<ActionEvent> ()
            {
                public void handle(ActionEvent event)
                {
                    anc.getChildren().remove(scoreEffect);

                }
            });
            anc.getChildren().add(scoreEffect);
            anc.getChildren().remove(fill[row][column].imageview);

        }
    }
}




