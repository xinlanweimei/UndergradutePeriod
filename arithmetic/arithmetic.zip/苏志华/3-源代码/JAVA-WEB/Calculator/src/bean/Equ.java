package bean;

public class Equ {

}
