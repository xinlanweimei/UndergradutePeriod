package bean;

public class User {

}
