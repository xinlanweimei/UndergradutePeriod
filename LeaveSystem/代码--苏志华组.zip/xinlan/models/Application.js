/**
 * Created by XINLAN on 2016/12/1.
 */
var mongoose = require('mongoose');
var User=require('../models/User');
var applySchema = new mongoose.Schema({
    uid: String,
    stime:Date,
    etime:Date,
    class:String,
    reason:String,
    status:String,
    atime:Date,
    createdOn: {
        type: Date,
        default: Date.now
    }
});


module.exports = mongoose.model('Application', applySchema);