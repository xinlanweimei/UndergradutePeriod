/**
 * Created by XINLAN on 2016/12/1.
 */
var mongoose = require('mongoose');
var crypto = require('crypto');
var jwt = require('jsonwebtoken');

var userSchema = new mongoose.Schema({
    uid: { type: String,unique: true, required: true },
    uname:String,
    hash: String,
    salt:String,
    days:String,
    level:String,
    createdOn: {
        type: Date,
        default: Date.now
    }
});

userSchema.methods.setPassword = function(password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    //1000代表迭代次数 64代表长度
    this.hash = crypto.pbkdf2Sync(password, this.salt,1000,64).toString('hex');
    return{
        salt:this.salt,
        hash:this.hash
    }
};

userSchema.methods.validPassword = function(password) {
    var hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64).toString('hex');
    return this.hash === hash;
};
userSchema.methods.generateJwt = function() {
    var expiry = new Date();
    expiry.setDate(expiry.getDate() + 7);
    var role = null;
    if(this.level == "管理员")
        role = 0;
    else
        role = 1;
    return jwt.sign({
        _id: this._id,
        uid: this.uid,
        role:role,
        exp:parseInt(expiry.getTime()/1000)}, process.env.JWT_SECRET);
};


module.exports = mongoose.model('User', userSchema);