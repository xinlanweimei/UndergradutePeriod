﻿
app.config(["$stateProvider","$urlRouterProvider",routeFn]);
function routeFn($stateProvider,$urlRouterProvider){
   $urlRouterProvider.otherwise("/");
    $stateProvider
        .state("/",{
            url:"/",
            templateUrl:"/front/views/welcome.html",
            controller:"welcomeCtrl",
            cache:'false',
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/welcomeCtrl.js");
                }]
            }
        })
        .state("homeUser",{
            url:"/homeUser",
            templateUrl:"/front/views/homeUser.html",
           controller:"homeCtrl",
           controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/homeCtrl.js");
                }]
            }
        })
        .state("homeAdmin",{
            url:"/homeAdmin",
            templateUrl:"/front/views/homeAdmin.html",
            controller:"homeCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/homeCtrl.js");
                }]
            }
        })
        .state("apply",{
            url:"/apply",
            templateUrl:"/front/views/apply.html",
            controller:"applyCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{

                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/applyCtrl.js");
                }],
                loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('/front/services/applyService.js');
                }]
            }
        })
        .state("info",{
            url:"/info",
            templateUrl:"/front/views/info.html",
            controller:"userCtrl",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/userCtrl.js");
                }]
            }
        })
        .state("adminfo",{
            url:"/adminfo",
            templateUrl:"/front/views/adminfo.html",
            controller:"userCtrl",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/userCtrl.js");
                }]
            }
        })
        .state("deal",{
            url:"/deal",
            templateUrl:"/front/views/deal.html",
            controller:"applyCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/applyCtrl.js");
                }],
                loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('/front/services/applyService.js');
                }]
            }
        })
        .state("doc",{
            url:"/doc",
            templateUrl:"/front/views/doc.html",
            controller:"userCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/userCtrl.js");
                }],
                loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load('/front/services/applyService.js');
               }]
            }
        })
        .state("updatepass",{
            url:"/updatepass",
            templateUrl:"/front/views/updatepass.html",
            controller:"updatepassCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/updatepassCtrl.js");
                }]
            }
        })
        .state("updateAdminpass",{
            url:"/updateAdminpass",
            templateUrl:"/front/views/updateAdminpass.html",
            controller:"updateAdminpassCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/updateAdminpassCtrl.js");
                }]
            }
        })
        .state("addUser",{
            url:"/addUser",
            templateUrl:"/front/views/addUser.html",
            controller:"addUserCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '0' },
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/addUserCtrl.js");
                }]
            }
        })
        .state("login",{
            url:"/login",
            templateUrl:"/front/views/login.html",
            controller:"loginCtrl",
            controllerAs:"vm",
            cache:'false',
            resolve:{
                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/loginCtrl.js");
                }]
            }
        })
        .state("personaldoc",{
            url:"/personaldoc",
            templateUrl:"/front/views/personaldoc.html",
            controller:"applyCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{

                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/applyCtrl.js");
                }],
                loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('/front/services/applyService.js');
                }]
            }
        })
        .state("otherdoc",{
            url:"/otherdoc",
            templateUrl:"/front/views/otherdoc.html",
            controller:"applyCtrl",
            controllerAs:"vm",
            cache:'false',
            data: {  requireRole: '1' },
            resolve:{

                loadMyCtrl:["$ocLazyLoad",function($ocLazyLoad){
                    return $ocLazyLoad.load("/front/controllers/applyCtrl.js");
                }],
                loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('/front/services/applyService.js');
                }]
            }
        })
}


