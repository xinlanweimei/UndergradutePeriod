/**
 * Created by XINLAN on 2016/12/12.
 */
var app = angular.module('app', ['ngResource','ui.router','oc.lazyLoad']);
app.config(["$provide", "$compileProvider", "$controllerProvider", "$filterProvider",
    function ($provide, $compileProvider, $controllerProvider, $filterProvider) {
        app.controller = $controllerProvider.register;
        app.directive = $compileProvider.directive;
        app.filter = $filterProvider.register;
        app.factory = $provide.factory;
        app.service = $provide.service;
        app.constant = $provide.constant;
    }]);
app.constant('Modules_Config', [
    {
        name: 'treeControl',
        series: true,
        files: []
    }
]);
app.config(["$ocLazyLoadProvider","Modules_Config",routeFn]);
function routeFn($ocLazyLoadProvider,Modules_Config){
    $ocLazyLoadProvider.config({
        debug:false,
        events:false,
        modules:Modules_Config
    });
}
app.config(function ($httpProvider) {
    $httpProvider.interceptors.push('TokenInterceptor');
});

app.directive('navigation', navigation);
function navigation() {
    return {
        restrict: 'EA',
        templateUrl: '/front/views/navigation.html',
        controller: 'navigationCtrl as navm'
    };
}

app.directive('sidebarUser', sidebarUser);
function sidebarUser() {
    return {
        restrict: 'EA',
        templateUrl: '/front/views/sidebarUser.html'
    };
}

app.directive('sidebarAdmin', sidebarAdmin);
function sidebarAdmin() {
    return {
        restrict: 'EA',
        templateUrl: '/front/views/sidebarAdmin.html'
    };
}

app.run(['$rootScope', '$state', '$window','authentication',function($rootScope, $state,$window,authentication) {

    // $stateChangeStart is fired whenever the state changes. We can use some parameters
    // such as toState to hook into details about the state as it is changing
    $rootScope.$on('$stateChangeStart', function(event, toState) {
        var role = authentication.currentUser().role;
        $rootScope.role = role;
        // Redirect user is NOT authenticated and accesing private pages
        var requireRole = toState.data !== undefined
           && toState.data.requireRole;
         if (requireRole == 0 && role == 1){
             $state.go('homeUser');
             event.preventDefault();
             return;
         }
        if (requireRole == 1 && role == 0){
            $state.go('homeAdmin');
            event.preventDefault();
            return;
        }
    })
}]);


app.service('authentication', authentication);
authentication.$inject = ['$window','$http'];
function authentication($window, $http) {
    var saveToken = function (token) {
        $window.localStorage['read-token'] = token;
    };
    var getToken = function () {
        return $window.localStorage['read-token'];
    };
    var register = function(user) {
        return $http.post('/register', user).success(function(data) {
        });
    };
    var login = function(user) {
        return $http.post('/login', user).success(function(data) {
            saveToken(data.token);
        });
    };
    var update = function(id,user) {
        return $http.put('/update/'+id, user);
    };
    var updatepass = function(user) {
        return $http.post('/updatepass', user);
    };
    var logout = function() {
        $window.localStorage.removeItem('read-token');
    };

    var isLoggedIn = function() {
        var token = getToken();
        if (token) {
            var payload = JSON.parse($window.atob(token.split('.')[1]));
            return payload.exp > Date.now() / 1000;
        } else {
            return false;
        }
    };
    var currentUser = function() {
        if (isLoggedIn()) {
            var token = getToken();
            var payload = JSON.parse($window.atob(token.split('.')[1]));
            return {
                _id:payload._id,
                uid: payload.uid,
                role:payload.role
            };
        }else return{
            _id:null
        }
    };
    return {
        saveToken: saveToken,
        getToken: getToken,
        register: register,
        login: login,
        logout: logout,
        update:update,
        updatepass:updatepass,
        isLoggedIn: isLoggedIn,
        currentUser: currentUser
    };
}


app.factory('TokenInterceptor', function ($q, $window) {
    return {
        request: function (config) {
            config.headers = config.headers || {};
            if ($window.localStorage['read-token']) {
                config.headers.Authorization = 'Bearer ' + $window.localStorage['read-token'];
            }
            return config;
        },

        response: function (response) {
            return response || $q.when(response);
        }
    };
});


app.factory('Users', ['$resource', function($resource){
    return $resource('/users/:id', null, {
        update: { method:'PUT' },
        get: { method:'get',isArray:true }
    });
}]);

app.controller('navigationCtrl', navigationCtrl);
navigationCtrl.$inject = ['$location','Users', 'authentication'];
function navigationCtrl($location,Users,authentication) {

    var vm = this;
    vm.isLoggedIn = authentication.isLoggedIn();
    if(vm.isLoggedIn) {
        var user = Users.get({id: authentication.currentUser()._id}, function () {
            vm.currentUser = user[0].uname;
        });
    }
    vm.logout = function () {
        authentication.logout();
        $location.path('/');
    };
}