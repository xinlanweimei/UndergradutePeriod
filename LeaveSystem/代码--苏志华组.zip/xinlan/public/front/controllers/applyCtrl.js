/**
 * Created by XINLAN on 2016/12/13.
 */
/**
 * Created by XINLAN on 2016/12/13.
 */
(function () {
    app.controller('applyCtrl', applyCtrl);
    applyCtrl.$inject = ['$state','$window','authentication','applyService','applications','otherdocs','Users'];
    function applyCtrl($state,$window,authentication,applyService,applications,otherdocs,Users) {
        if (angular.isUndefined($window.localStorage['read-token'])) {
            $window.alert("请先登录");
            $state.go("login", {}, {reload: true});
        }
        var vm = this;
        vm.editing = [];
        vm.com = {
            id:"",
            stime: "",
            etime: '',
            class:'',
            reason:''
        };
        vm.class = ["事假","病假","婚假","产假","其他"];
        vm.com.id = authentication.currentUser().uid;

         vm.perdoc  = applications.get({id: vm.com.id});
         vm.otherdoc = otherdocs.get({id:vm.com.id});
         vm.doc = applications.get();
        vm.onSubmit = function() {
            vm.formError = "";
            if (!vm.com.stime || !vm.com.etime || !vm.com.class || !vm.com.reason) {
                vm.formError = "需要填完所有字段!";
                return false;
            } else {
                vm.apply();
            }
        };
        vm.formatTime = function(time) {
            var result = moment(time).format('YYYY-MM-DD HH:mm');
          if(result == "Invalid date")
              result = "";
          return result;

        };
        vm.formatStatus = function(status) {
            vm.status = status;
           if(status == "待处理"){
               return {'label label-success':false,'label label-danger':false,'label label-primary':true};

           }else if(status == "同意"){
              return  {'label label-success':true,'label label-danger':false,'label label-primary':false};
           }
           else{
             return {'label label-success':false,'label label-danger':true,'label label-primary':false};
           }
        };
        vm.apply = function() {
            vm.formError = "";
            applyService.apply(vm.com).error(function(err) {
                vm.formError = err.message;
            }).then(function() {
                $window.alert("申请成功!");
                vm.com = {
                    id:"",
                    stime: "",
                    etime: '',
                    class:'',
                    reason:''
                };
                $state.go("apply", {}, { reload: true });
            });
        };



        vm.update = function(index){
            var perdoc = vm.perdoc[index];
            if(typeof(vm.stime) != "undefined"){
                perdoc.stime = vm.stime;
            }
            if(typeof(vm.etime) != "undefined"){
                perdoc.etime = vm.etime;
            }
            if(perdoc.status == "拒绝" || perdoc.status == "同意"){
                $window.alert("已处理，无法修改");
                $state.go("personaldoc", {}, { reload: true });
            }else {
                applyService.updateApply(perdoc._id, perdoc).error(function (err) {
                    $window.alert(err.message);
                    $state.go("personaldoc", {}, {reload: true});
                }).then(function () {
                    $state.go("personaldoc", {}, {reload: true});
                });
            }
        };

        vm.edit = function(index){
            vm.editing[index] = angular.copy(vm.perdoc[index]);
        };

        vm.cancel = function(index){
            vm.perdoc[index] = angular.copy(vm.editing[index]);
            vm.editing[index] = false;
            $state.go("personaldoc", {}, { reload: true });
        };
        vm.remove = function(index){
            var perdoc = vm.perdoc[index];
            applications.remove({id: perdoc._id}, function(){
                vm.perdoc.splice(index, 1);
                $state.go("personaldoc", {}, { reload: true });
            });
        };

        vm.agree = function (index) {
            var deal = vm.doc[index];
            if(deal.status == "待处理") {
                deal.status = "同意";
                deal.atime = Date.now();
                applyService.reduceDays(deal._id, deal).error(function (err) {
                    $window.alert(err.message);
                    $state.go("deal", {}, {reload: true});
                }).then(function () {
                    $state.go("deal", {}, {reload: true});
                });
            }else{
                $window.alert("已处理");
                $state.go("deal", {}, {reload: true});
            }

        };
        vm.disagree = function (index) {
            var deal = vm.doc[index];
            if(deal.status == "待处理") {
                deal.status = "拒绝";
                deal.atime = Date.now();
                applyService.updateApply(deal._id, deal).error(function (err) {
                    $window.alert(err.message);
                    $state.go("deal", {}, {reload: true});
                }).then(function () {
                    $state.go("deal", {}, {reload: true});
                });
            }else{
                $window.alert("已处理");
                $state.go("deal", {}, {reload: true});
            }
        }

    }
}());
