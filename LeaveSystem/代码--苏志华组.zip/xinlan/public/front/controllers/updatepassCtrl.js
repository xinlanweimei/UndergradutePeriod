/**
 * Created by XINLAN on 2016/12/12.
 */
/**
 * Created by XINLAN on 2016/12/1.
 */
(function () {
    app.controller('updatepassCtrl', updatepassCtrl);
    updatepassCtrl.$inject = ['$location','$state', '$window','authentication'];
    function updatepassCtrl($location,$state,$window,authentication) {
        if (angular.isUndefined($window.localStorage['read-token'])) {
            $window.alert("请先登录");
            $state.go("login", {}, {reload: true});
        }
        var vm = this;
        vm.password = {
            id:'',
            old : '',
            new1 : '',
            new2 : ''
        };
        vm.password.id = authentication.currentUser()._id;
        vm.onSubmit = function () {
            if (!vm.password.old || !vm.password.new1 || !vm.password.new2) {
                $window.alert("所填字段不能为空!");
                $state.go("updatepass", {}, { reload: true });
                return false;
            } else if(vm.password.new1 != vm.password.new2){
                $window.alert("两次密码不一致!");
                $state.go("updatepass", {}, { reload: true });
                return false;
            }else{
                vm.updatepass();
            }
        };
        vm.updatepass = function () {
            authentication.updatepass(vm.password).error(function(err){
                $window.alert(err.message);
                $state.go("updatepass", {}, { reload: true });
                return false;
            }).then(function(){
                $window.alert("修改成功，请重新登录!");
                authentication.logout();
                $location.path('/');
            });
        };
    }
}());
