/**
 * Created by XINLAN on 2016/12/9.
 */
(function () {
    app.controller('homeCtrl', homeCtrl);
    homeCtrl.$inject = ['$state', '$window'];
    function homeCtrl($state,$window) {
        if (angular.isUndefined($window.localStorage['read-token'])) {
            $window.alert("请先登录");
            $state.go("login", {}, {reload: true});
        }
    }
}());