/**
 * Created by XINLAN on 2016/12/9.
 */
(function () {
    app.controller('welcomeCtrl', welcomeCtrl);
    welcomeCtrl.$inject = ['$state', '$window','authentication','Users'];
    function welcomeCtrl($state,$window,authentication,Users) {
       if (!angular.isUndefined($window.localStorage['read-token'])) {
            var user = Users.get({id:authentication.currentUser()._id},function() {
                var level = user[0].level;
                $window.alert("您已登录,即将返回首页");
                if(level == "普通员工")
                    $state.go("homeUser", {}, {reload: true});
                else
                    $state.go("homeAdmin", {}, {reload: true});
            });
        }
    }
}());