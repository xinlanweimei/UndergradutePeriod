/**
 * Created by XINLAN on 2016/12/1.
 */
(function () {
    app.controller('loginCtrl', loginCtrl);
    loginCtrl.$inject = ['$location','$state', '$window','authentication','Users'];
    function loginCtrl($location,$state,$window,authentication,Users) {
        if (!angular.isUndefined($window.localStorage['read-token'])) {
            var user = Users.get({id:authentication.currentUser()._id},function() {
                var level = user[0].level;
                $window.alert("您已登录,即将返回首页");
                if(level == "普通员工")
                    $state.go("homeUser", {}, {reload: true});
                else
                    $state.go("homeAdmin", {}, {reload: true});
            });
        }
        var vm = this;
        vm.credentials = {
            uid: '',
            password: '',
            level:''
        };
        vm.onSubmit = function () {
            vm.formError = "";
            if (!vm.credentials.uid || !vm.credentials.password) {
                vm.formError = "请输入用户名和密码!";
                return false;
            } else {
                vm.doLogin();
            }
        };
        vm.doLogin = function () {
            vm.formError = "";
            authentication.login(vm.credentials).error(function (err) {
                vm.formError = err.message;
            }).then(function () {
                if(vm.credentials.level == "管理员")
                  $location.path('/homeAdmin');
                else
                    $location.path('/homeUser');
            });
        };
    }
}());
