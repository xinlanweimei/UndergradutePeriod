/**
 * Created by XINLAN on 2016/12/9.
 */
(function () {
    app.controller('userCtrl', ['$scope','$window','$state','Users','authentication','removeApp',
        function ($scope,$window,$state,Users,authentication,removeApp) {
        if(angular.isUndefined($window.localStorage['read-token'])){
            $window.alert("请先登录");
            $state.go("login", {}, { reload: true });
        }
         var user = Users.get({id:authentication.currentUser()._id},function() {
             $scope.user = user[0];
        });
            var vm = this;
            vm.index = {
                id: '',
                judge:''
            };
            vm.level = ["普通员工","管理员"]
            vm.editing = [];
             var users = Users.get({},function () {
                 vm.users = users;
                 vm.pageSize = 2;
                 vm.curPage = 0;
                 vm.pageCount = Math.ceil(vm.users.length / vm.pageSize) - 1;
             });

            vm.update = function(item){
                var user = item;
                var index = vm.users.indexOf(item);
                if(user._id == authentication.currentUser()._id &&
                    user.uid != authentication.currentUser().uid){
                    $window.alert("无法修改当前用户ID");
                    $state.go("doc", {}, {reload: true});
                }else {
                    authentication.update(user._id, user).error(function (err) {
                        $window.alert(err.message);
                        $state.go("doc", {}, {reload: true});
                    }).then(function () {
                        $window.alert("修改成功");
                        $state.go("doc", {}, {reload: true});
                    });
                }
                vm.editing[index] = false;
            };

            vm.edit = function(item){
                var index = vm.users.indexOf(item);
                vm.editing[index] = angular.copy(vm.users[index]);
            };

            vm.cancel = function(item){
                var index = vm.users.indexOf(item);
                vm.users[index] = angular.copy(vm.editing[index]);
                vm.editing[index] = false;
            };
            vm.remove = function(item){
                var index = vm.users.indexOf(item);
                var user = vm.users[index];
                if(user.uid == authentication.currentUser().uid)
                    $window.alert("无法删除当前用户");
                else {
                    Users.remove({id: user._id}, function () {
                        vm.users.splice(index, 1);
                    });
                    removeApp.remove({uid: user.uid}, function () {
                        $state.go("doc", {}, {reload: true});
                    });
                }
            }
    }]);

    app.filter('pageStartFrom', [function() {
        return function(input, start) {
            if (!input || !input.length) { return; }
            start = +start; //parse to int
            return input.slice(start);
        }
    }]);
}());

