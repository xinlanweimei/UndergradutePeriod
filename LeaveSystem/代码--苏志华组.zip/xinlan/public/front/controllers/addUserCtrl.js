/**
 * Created by XINLAN on 2016/12/13.
 */
(function () {
    app.controller('addUserCtrl', addUserCtrl);
    addUserCtrl.$inject = ['$state','$window','authentication'];
    function addUserCtrl($state,$window,authentication) {
        if (angular.isUndefined($window.localStorage['read-token'])) {
            $window.alert("请先登录");
            $state.go("login", {}, {reload: true});
        }
        var vm = this;
        vm.com = {
            uid: "",
            uname: '',
            password:'',
            level:'',
            days:''
        };
        vm.onSubmit = function() {
            vm.formError = "";
            if (!vm.com.uid || !vm.com.uname || !vm.com.password
            || !vm.com.level || !vm.com.days) {
                vm.formError = "需要填完所有字段!";
                return false;
            } else {
                vm.addUser();
            }
        };
        vm.addUser = function() {
            vm.formError = "";
            authentication.register(vm.com).error(function(err) {
                vm.formError = err.message;
            }).then(function() {
                $window.alert("添加成功!");
                vm.com = {
                    uid: "",
                    uname: '',
                    password:'',
                    level:'',
                    days:''
                };
                $state.go("addUser", {}, { reload: true });
            });
        };
    }
}());
