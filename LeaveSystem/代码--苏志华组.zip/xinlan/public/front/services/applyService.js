/**
 * Created by XINLAN on 2016/12/13.
 */
(function () {
app.service('applyService', applyService);
applyService.$inject = ['$http'];
function applyService($http) {
    var apply = function(application) {
        return $http.post('/apply', application).success(function(data) {
        });
    };
    var updateApply = function(id,application) {
        return $http.put('/applications/'+id, application).success(function(data) {
        });
    };
    var reduceDays= function(id,application) {
        return $http.put('/reduceDays/'+id, application).success(function(data) {
        });
    };
    return {
        apply: apply,
        updateApply:updateApply,
        reduceDays:reduceDays
    };
}

app.factory('applications', ['$resource', function($resource){
        return $resource('/applications/:id', null, {
            update: { method:'PUT' },
            get:{method:'GET',  isArray:true}
        });
    }]);

app.factory('removeApp', ['$resource', function($resource){
        return $resource('/removeApp/:uid', null, {
            update: { method:'PUT' },
            get:{method:'GET',  isArray:true}
        });
    }]);

    app.factory('otherdocs', ['$resource', function($resource){
        return $resource('/otherdocs/:id', null, {
            update: { method:'PUT' },
            get:{method:'GET',  isArray:true}
        });
    }]);

}());