var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var User = require('../models/User.js');
passport.use(new LocalStrategy({
    usernameField:'uid',
    passReqToCallback: true
},function(req,username, password,done) {
    if(!req.body.level){
        return done(null, false, { message: '请选择身份!' });
    }
    User.findOne({ uid: username,level:req.body.level }, function(err, user) {
        if (err) {
            return done(err);
        }
        if (!user) {
            return done(null, false, { message: '用户不存在！' });
        }
        if (!user.validPassword(password)) {
            return done(null, false, { message: '密码错误!' });
        }
        return done(null, user);

    });
}));