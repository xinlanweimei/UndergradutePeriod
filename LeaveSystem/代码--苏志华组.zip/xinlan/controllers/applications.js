/**
 * Created by XINLAN on 2016/12/13.
 */
var mongoose = require('mongoose');
var User = require('../models/User.js');
var Application = require('../models/Application.js');
var identify = require('./identify');
var moment = require('moment');
var sendJSONresponse =  identify.sendJSONresponse;
var async = require('async');

module.exports.apply = function(req, res) {
    var application = new Application();
    var date1 = new Date(Date.now());
    var date2 = new Date(req.body.stime);  //开始时间
     var date3 = new Date(req.body.etime);
    var time1 = date3.getTime() - date2.getTime(); //时间差的毫秒数
    var time2 = date2.getTime() - date1.getTime();
    if(time1 < 0){
        sendJSONresponse(res, 400, { message: "请假结束时间不能早于请假开始时间" });
        return;
    }
    if(time2 < 0){
        sendJSONresponse(res, 400, { message: "请假开始时间不能早于当前申请时间" });
        return;
    }
 //计算出相差天数
    var days=Math.floor(time1/(24*3600*1000));
    User.find({uid:req.body.id},function (err1, user) {
        if (err1){
            sendJSONresponse(res, 400, { message: "用户不存在" });
            return;
        }
        if(days > parseInt(user[0].days)){
            sendJSONresponse(res, 400, { message: "年假剩余天数不够" });
            return;
        }else{
            application.uid = req.body.id;
            application.stime = req.body.stime;
            application.etime = req.body.etime;
            application.reason = req.body.reason;
            if(req.body.class == "1")
               application.class = "事假";
            else if(req.body.class == "2")
               application.class = "病假";
            else if(req.body.class == "3")
               application.class = "婚假";
            else if(req.body.class == "4")
               application.class = "产假";
            else
                application.class = "其他";
            application.status = "待处理";
            application.atime = "";
            application.save(function(err2) {
                if (err2) {
                    sendJSONresponse(res, 400, { message: "申请失败" });
                } else {
                    sendJSONresponse(res, 200, { message: "申请成功" });
                }

            });
        }
    });
};

module.exports.applicationList = function (req, res) {
    Application.find({},null,{sort:{createdOn:-1}},function (err, users) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, users);
    });
};


module.exports.personaldocGet = function (req, res) {
   Application.find({uid:req.params.id},null,{sort:{stime:-1}}, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};

module.exports.otherdocGet = function (req, res) {
    Application.$where('this.uid != "' + req.params.id + '"').exec(function (err1, docs) {
        if (err1) {
            sendJSONresponse(res, 400, err1);
            return;
        }
        async.map(docs,function (doc,callback) {
            User.find({uid:doc.uid}, function (err2, users) {
                doc._doc.uname = users[0].uname;
                callback(null,doc);
            })
        },function(err3,results) {
            sendJSONresponse(res, 200, results);
        });
    })
};



module.exports.personaldocDelete = function (req, res) {
    Application.findByIdAndRemove(req.params.id, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};

module.exports.docDelete = function (req, res) {
    Application.remove({uid:req.params.uid}, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};

module.exports.personaldocUpdate = function (req, res) {
    var date1 = new Date(Date.now());
    var date2 = new Date(req.body.stime);  //开始时间
    var date3 = new Date(req.body.etime);
    if(date2 == "Invalid Date" || date3 == "Invalid Date"){
        sendJSONresponse(res, 400, { message: "请按照格式输入合理时间" });
        return;
    }
    var time1 = date3.getTime() - date2.getTime(); //时间差的毫秒数
    var time2 = date2.getTime() - date1.getTime();
    if(time1 < 0){
        sendJSONresponse(res, 400, { message: "请假结束时间不能早于请假开始时间" });
        return;
    }
    if(time2 < 0){
        sendJSONresponse(res, 400, { message: "请假开始时间不能早于当前申请时间" });
        return;
    }

    User.find({uid:req.body.uid},function (err1, user) {
        if (err1) {
            sendJSONresponse(res, 400, {message: "用户不存在"});
            return;
        }
        var days=Math.floor(time1/(24*3600*1000));
        if (days > parseInt(user[0].days)) {
            sendJSONresponse(res, 400, {message: "年假剩余天数不够"});
            return;
        }else{
            Application.findByIdAndUpdate(req.params.id, req.body, function (err, post) {
                if (err){
                    sendJSONresponse(res, 400, err);
                    return;
                }
                sendJSONresponse(res, 200, post);
            });
        }
    });
};


module.exports.reduceDays = function (req, res) {

    var date1 = new Date(req.body.stime);  //开始时间
    var date2 = new Date(req.body.etime);
    var time = date2.getTime() - date1.getTime(); //时间差的毫秒数

    User.find({uid:req.body.uid},function (err1, user) {
        if (err1) {
            sendJSONresponse(res, 400, {message: "用户不存在"});
            return;
        }else{
        var days=Math.floor(time/(24*3600*1000));
        var remain = parseInt(user[0].days) - days;
        User.findByIdAndUpdate(user[0]._id, {days:remain}, function (err2, post) {
                if (err2){
                    sendJSONresponse(res, 400, err2);
                    return;
                }else{
                    Application.findByIdAndUpdate(req.params.id, req.body, function (err, post) {
                        if (err){
                            sendJSONresponse(res, 400, err);
                            return;
                        }
                        sendJSONresponse(res, 200, post);
                    });
                }
            });
        }
    });
};