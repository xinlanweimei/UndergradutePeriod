/**
 * Created by XINLAN on 2016/12/1.
 */
var passport = require('passport');
var mongoose = require('mongoose');
var User = require('../models/User.js');
var identify = require('./identify');
var sendJSONresponse =  identify.sendJSONresponse;
module.exports.register = function(req, res) {
    if (!req.body.uid || !req.body.uname || !req.body.password || !req.body.level || !req.body.days) {
        sendJSONresponse(res, 400, { message: "请完成所有字段" });
        return;
    }
    var rule1 = /^[3-4][0-9]$/;
    var rule2 = /^[5][0]$/;
    if(!rule1.test(req.body.days) && !rule2.test(req.body.days)){
        sendJSONresponse(res, 400, { message: "假期为30-50天" });
        return;
    }
    var user = new User();
    user.uid = req.body.uid;
    user.level = req.body.level;
    user.days = req.body.days;
    user.uname = req.body.uname;
    user.setPassword(req.body.password);
    user.save(function(err) {
        var token;
        if (err) {
            sendJSONresponse(res, 404, { message: "用户已存在" });
        } else {
            token = user.generateJwt();
            sendJSONresponse(res, 200, { 'token': token });
        }

    });
};


module.exports.login = function(req, res) {
    if (!req.body.uid || !req.body.password) {
        sendJSONresponse(res, 400, { message: '请输入用户名和密码!' });
        return;
    }
    passport.authenticate('local', function(err, user, info) {
        var token;
        if (err) {
            sendJSONresponse(err, 404, err);
            return;
        }
        if (user) {
            token = user.generateJwt();
            sendJSONresponse(res, 200, { token: token });
        } else {
            sendJSONresponse(res, 401, info);
        }

    })(req,res);
};

module.exports.updatepass = function(req, res,done) {
    User.findById(req.body.id,function(err, user) {
        if (err) {
            sendJSONresponse(err, 404, err);
            return;
        }
        if (!user) {
            sendJSONresponse(res, 400, { message: '用户不存在!' });
        }
        if (!user.validPassword(req.body.old)) {
            return  sendJSONresponse(res, 400, { message: '原密码错误!' });
        }
        var newpass = user.setPassword(req.body.new1);
        var newsalt = newpass.salt;
        var newhash = newpass.hash;
        User.findByIdAndUpdate(req.body.id, {$set:{salt:newsalt,hash:newhash}}, function (err, post) {
            if (err){
                sendJSONresponse(res, 400, err);
                return;
            }
            sendJSONresponse(res, 200, post);
        });

    });
};

module.exports.userList = function (req, res) {
    User.find({},null,{sort:{createdOn:1}},function (err, users) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, users);
    });
};

module.exports.userGet = function (req, res) {
    User.find({_id:req.params.id}, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};

module.exports.userCreate = function (req, res) {
    User.create(req.body, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};

module.exports.userUpdate = function (req, res) {
    var rule = /^[0-9]+$/;

    if(!rule.test(req.body.days) || parseInt(req.body.days) > 50){
        sendJSONresponse(res, 400, { message: "请输入合理的天数，不能多于50天" });
        return;
    }

    User.findById(req.params.id,function(err, user) {
        if (err) {
            sendJSONresponse(err, 400, {message:"无此用户"});
            return;
        }
        if(user.salt == req.body.salt){
            User.findByIdAndUpdate(req.params.id, {
                $set: {
                    uid: req.body.uid, uname: req.body.uname, level: req.body.level, days: req.body.days
                }
            }, function (err, post) {
                if (err) {
                    sendJSONresponse(res, 400, {message: "用户已存在"});
                    return;
                }
                sendJSONresponse(res, 200, post);
            });
        }else {
            var newpass = user.setPassword(req.body.salt);
            var newsalt = newpass.salt;
            var newhash = newpass.hash;
            User.findByIdAndUpdate(req.params.id, {
                $set: {
                    salt: newsalt, hash: newhash,
                    uid: req.body.uid, uname: req.body.uname, level: req.body.level, days: req.body.days
                }
            }, function (err, post) {
                if (err) {
                    sendJSONresponse(res, 400, {message: "用户已存在"});
                    return;
                }
                sendJSONresponse(res, 200, post);
            });
        }
    });
};

module.exports.userDelete = function (req, res) {
    User.findByIdAndRemove(req.params.id, req.body, function (err, post) {
        if (err){
            sendJSONresponse(res, 400, err);
            return;
        }
        sendJSONresponse(res, 200, post);
    });
};


