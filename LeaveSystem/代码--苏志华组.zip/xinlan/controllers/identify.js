/**
 * Created by XINLAN on 2016/12/7.
 */

var sendJSON = function (res, status, content) {
    res.status(status);
    res.json(content);
};

module.exports.sendJSONresponse = sendJSON;
